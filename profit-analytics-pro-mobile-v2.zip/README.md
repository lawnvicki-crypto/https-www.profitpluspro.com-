# Profit Analytics Pro Mobile V2

Mobile-first React/Vite dashboard for iPhone Safari.

## Important
This package contains the mobile UI and local research backtest. For live Deriv ticks, the deployment must expose a WebSocket endpoint at `/ws` that sends messages shaped like:
`{"type":"tick","tick":{"quote":123.45,"digit":5,"symbol":"R_100","time":"..."}}`

The existing backend from V1 can be adapted to provide that endpoint. This project intentionally does not execute trades or process payments.

## Run
npm install
npm run dev

For production:
npm run build
